# Executive Summary
## Nassau Candy Distributor — Factory-to-Customer Shipping Route Efficiency

### Prepared by: Data Science Intern

### Purpose
This project provides a data-driven view of shipping performance across Nassau Candy Distributor's factory-to-customer network. The analysis identifies route-level performance, geographic patterns and shipping-mode differences through an interactive Streamlit dashboard.

### Scope
The supplied dataset contains **10,194 shipment records**, **8,549 unique orders**, **5 factories**, **15 mapped products**, and **59 customer state/province values**.

### Core KPIs
- Shipping Lead Time
- Average Lead Time
- Route Volume
- Delay Frequency
- Lead-Time Variability
- Route Efficiency Score

### Main analytical result
The project successfully maps all products to their supplying factories and creates factory-to-customer-state routes. This enables route ranking, state-level analysis, ship-mode comparison and order-level drill-down.

### Critical validation issue
The dataset contains order dates from **2024-01-02 to 2025-12-31** but ship dates from **2026-06-30 to 2030-06-28**. The resulting lead times are **904–1642 days**.

This is not typical for physical shipping and should be validated before the findings are used for actual logistics policy or operational decisions.

### Recommended action
1. Validate the source date fields.
2. Establish service-level thresholds by ship mode.
3. Prioritize high-volume, high-lead-time routes.
4. Monitor route performance continuously through the dashboard.
5. Extend the project with distance, carrier, inventory and capacity data.
6. Build a predictive late-delivery model after the data-quality issue is resolved.

### Dashboard
The Streamlit dashboard contains:
- Route Efficiency Overview
- Geographic Shipping Map
- Ship Mode Comparison
- Route Drill-Down
- Interactive date, region, state, ship-mode and threshold filters

### Value to stakeholders
The solution changes logistics analysis from reactive reporting to repeatable, data-driven monitoring. It can help decision-makers focus attention on routes that have the greatest operational impact while providing a foundation for predictive logistics optimization.
