# Factory-to-Customer Shipping Route Efficiency Analysis

## Nassau Candy Distributor | Data Science Internship Project

### Project objective
Analyze factory-to-customer shipping performance and convert order/shipment data into route-level operational intelligence.

### Tech stack
- Python
- Pandas / NumPy
- Plotly
- Streamlit
- CSV data

### Dashboard modules
1. Route Efficiency Overview
2. Geographic Shipping Map
3. Ship Mode Comparison
4. Route Drill-Down

### User filters
- Order date range
- Region
- State / Province
- Ship mode
- Lead-time delay threshold
- Minimum shipment count for route ranking

### How to run
```bash
pip install -r requirements.txt
streamlit run app.py
```

Keep `Nassau Candy Distributor.csv` in the same folder as `app.py`, or upload it from the dashboard.

### Important data-quality observation
The supplied dataset has order dates in 2024–2025 and ship dates in 2026–2030. This creates lead times of approximately 904–1,642 days. That is highly unusual for parcel shipping and should be validated with the source system before using the results for real operational decisions.

### Factory mapping
The project maps products to factories using the product–factory correlation supplied in the project brief.

### Route definition
`Factory → Customer State`

### Core KPIs
- Shipping Lead Time = Ship Date − Order Date
- Average Lead Time
- Route Volume
- Delay Frequency
- Lead-Time Variability
- Route Efficiency Score

### Suggested internship presentation
Explain the project in this order:
1. Business problem
2. Dataset and data cleaning
3. Product-to-factory mapping
4. Feature engineering
5. Route aggregation
6. KPI design
7. EDA findings
8. Streamlit dashboard
9. Data-quality limitation
10. Recommendations and future scope
