# Research / Project Report
## Factory-to-Customer Shipping Route Efficiency Analysis for Nassau Candy Distributor

**Role:** Data Science Intern  
**Tools:** Python, Pandas, NumPy, Plotly, Streamlit  
**Dataset:** Nassau Candy Distributor CSV  
**Records:** 10,194  
**Fields:** 23

---

## 1. Abstract

Nassau Candy Distributor operates a multi-factory distribution network in which products are shipped to customers across multiple regions and states. This project develops a data-driven route efficiency analysis system to identify high-performing and under-performing factory-to-customer routes, compare shipping modes, detect geographic bottlenecks, and support operational decision-making.

The analysis combines data cleaning, date-based feature engineering, product-to-factory mapping, route aggregation, KPI development, exploratory data analysis, and an interactive Streamlit dashboard. The central route definition is **Factory → Customer State**, with region-level analysis used for broader geographic comparisons.

A major limitation was identified during validation: the supplied order dates range from 2024–2025 while ship dates range from 2026–2030. Consequently, calculated lead times range from 904 to 1,642 days, which is unusually high for normal parcel shipping. The dashboard intentionally preserves these values while clearly flagging the issue so that a data science intern can demonstrate responsible data validation rather than hiding an anomaly.

---

## 2. Business Problem

The distributor lacks clear visibility into:
- consistently efficient factory-to-customer routes;
- routes with frequent delays;
- performance differences by region, state, and ship mode;
- geographic bottlenecks;
- operational areas where high shipment volume is combined with poor shipping performance.

The goal is to transform raw transaction records into route-level intelligence that can support logistics optimization.

---

## 3. Objectives

1. Validate and clean order and shipment data.
2. Calculate shipping lead time.
3. Map every product to its supplying factory.
4. Define and aggregate factory-to-customer routes.
5. Calculate average lead time and lead-time variability.
6. Rank the most and least efficient routes.
7. Analyze geographic performance by region and state.
8. Compare Standard, Second, First and Same Day shipping modes.
9. Provide configurable delay-frequency analysis.
10. Build an interactive Streamlit dashboard for decision support.

---

## 4. Dataset Overview

The dataset contains 10,194 records and 8,549 unique orders. There are 59 customer state/province values and 15 products.

### Main variables
- Row ID
- Order ID
- Order Date
- Ship Date
- Ship Mode
- Customer ID
- Country/Region
- City
- State/Province
- Postal Code
- Division
- Region
- Product ID
- Product Name
- Sales
- Units
- Gross Profit
- Cost

---

## 5. Data Cleaning and Validation

### Steps performed
- Parsed Order Date and Ship Date using day-first date interpretation.
- Checked for missing values.
- Calculated lead time as Ship Date − Order Date.
- Checked for negative lead times.
- Mapped products to factories using the supplied product-factory relationship.
- Standardized route construction as Factory → State.
- Created route-level and ship-mode summaries.

### Validation results
- Missing values in the original 18 fields: **0**
- Negative lead times: **0**
- Unmapped products after factory mapping: **0**
- Shipping lead time range: **904–1642 days**
- Average shipping lead time: **1320.8 days**
- Median shipping lead time: **1274 days**

### Critical data-quality finding
The order date range is **2024-01-02 to 2025-12-31**, whereas the ship date range is **2026-06-30 to 2030-06-28**.

This produces very large lead times. Before using this project for real logistics decisions, the source dates should be checked for:
- incorrect year values;
- date-format interpretation;
- synthetic/test-data transformations;
- delayed system migration or historical data offsets.

This is a key part of the data scientist's responsibility.

---

## 6. Product-to-Factory Mapping

The supplied mapping assigns:
- **Lot's O' Nuts:** three chocolate products.
- **Wicked Choccy's:** two chocolate products.
- **Sugar Shack:** five sugar/other products.
- **Secret Factory:** three products.
- **The Other Factory:** two products.

All 15 products in the dataset were successfully mapped.

---

## 7. Feature Engineering

### Shipping Lead Time
`Shipping Lead Time = Ship Date − Order Date`

### Route
`Route = Factory → Customer State`

### Delay Indicator
For the dashboard, a shipment is considered delayed when:

`Lead Time > selected threshold`

The default dashboard threshold is **1,300 days** because the supplied data contains unusually large lead times. The user can change the threshold interactively.

### Route Efficiency Score

A normalized score from 0 to 100 is calculated:

`Efficiency Score = 100 × (Maximum Route Average − Route Average) / (Maximum Route Average − Minimum Route Average)`

Higher scores represent lower average lead time.

---

## 8. Exploratory Data Analysis

### Shipping mode distribution

| Ship Mode | Shipments |
|---|---:|
| Standard Class | 6,120 |
| Second Class | 1,979 |
| First Class | 1,548 |
| Same Day | 547 |

### Region performance

| Region | Shipments | Avg Lead Time |
|---|---:|---:|
| Gulf | 1,620 | 1311.4 days |
| Pacific | 3,253 | 1322.2 days |
| Atlantic | 2,986 | 1322.7 days |
| Interior | 2,335 | 1323.1 days |

### Ship mode performance

| Ship Mode | Shipments | Avg Lead Time |
|---|---:|---:|
| Standard Class | 6,120 | 1314.3 days |
| Second Class | 1,979 | 1323.8 days |
| Same Day | 547 | 1333.4 days |
| First Class | 1,548 | 1338.3 days |

---

## 9. Route Efficiency Analysis

The route table contains **196 factory-to-state route combinations**.

For fairer ranking, the dashboard allows a minimum shipment-count filter so that a route with only one shipment does not automatically dominate the leaderboard.

### Raw fastest routes in the supplied data

| Route                           |   Shipments |   Average_Lead_Time |   Efficiency_Score |
|:--------------------------------|------------:|--------------------:|-------------------:|
| Secret Factory → New Mexico     |           2 |               906   |             100    |
| Secret Factory → Nebraska       |           1 |               906   |             100    |
| The Other Factory → Louisiana   |           1 |               907   |              99.86 |
| The Other Factory → Connecticut |           2 |               907.5 |              99.8  |
| Secret Factory → Mississippi    |           1 |               908   |              99.73 |
| Wicked Choccy's → Maine         |           2 |               908   |              99.73 |
| Secret Factory → Louisiana      |           2 |               908.5 |              99.66 |
| Secret Factory → Delaware       |           1 |               909   |              99.59 |
| Secret Factory → South Carolina |           1 |               909   |              99.59 |
| Secret Factory → Minnesota      |           1 |               909   |              99.59 |

### Raw slowest routes in the supplied data

| Route                           |   Shipments |   Average_Lead_Time |   Efficiency_Score |
|:--------------------------------|------------:|--------------------:|-------------------:|
| Sugar Shack → New Jersey        |           1 |              1642   |               0    |
| Secret Factory → New Hampshire  |           1 |              1641   |               0.14 |
| Sugar Shack → Connecticut       |           1 |              1641   |               0.14 |
| Wicked Choccy's → West Virginia |           2 |              1639   |               0.41 |
| Lot's O' Nuts → North Dakota    |           4 |              1638.2 |               0.52 |
| Sugar Shack → California        |           1 |              1638   |               0.54 |
| The Other Factory → Nevada      |           1 |              1638   |               0.54 |
| Sugar Shack → Washington        |           1 |              1638   |               0.54 |
| Secret Factory → Connecticut    |           1 |              1638   |               0.54 |
| Sugar Shack → Ohio              |           2 |              1637.5 |               0.61 |

Because several routes have very small volumes, these rankings should be interpreted together with shipment volume and variability.

---

## 10. Geographic Bottleneck Analysis

A geographic bottleneck should be considered important when it combines:
- high shipment volume;
- high average lead time;
- and/or high variability.

The Streamlit map highlights average lead time by US state. Non-US locations, such as Canadian records, are shown separately because the Plotly USA state geometry does not represent them.

A practical operational priority score can be developed in future work using:

`Priority = normalized volume × normalized lead time`

This would prevent low-volume routes from receiving the same attention as high-volume problem areas.

---

## 11. Ship Mode Analysis

The dashboard compares:
- Standard Class
- Second Class
- First Class
- Same Day

The comparison includes:
- shipment volume;
- average lead time;
- median lead time;
- lead-time variability;
- delay frequency;
- sales value.

The analysis is descriptive rather than causal. A shipping mode should not automatically be judged inefficient merely because its observed lead time is high, because order mix, geography, customer location, and product mix may differ between modes.

---

## 12. Streamlit Dashboard

### Module 1 — Route Efficiency Overview
Shows:
- average lead time by route;
- top 10 efficient routes;
- bottom 10 inefficient routes;
- route efficiency score;
- route volume;
- lead-time variability.

### Module 2 — Geographic Shipping Map
Shows:
- state-level average lead time;
- shipment volume;
- sales;
- factory-location context.

### Module 3 — Ship Mode Comparison
Shows:
- average lead time;
- delay frequency;
- shipment volume;
- variability.

### Module 4 — Route Drill-Down
Shows:
- selected route KPIs;
- order-level shipment timeline;
- order ID;
- product;
- factory;
- customer state;
- ship mode;
- order date;
- ship date;
- lead time.

---

## 13. Key Findings

1. **The dataset has a major date-quality issue.** The calculated lead times are much larger than expected for normal shipping operations.
2. **Standard Class has the highest shipment volume**, with 6,120 records.
3. **Gulf has the lowest observed regional average lead time** in the supplied data at approximately 1311.4 days.
4. **Route volume matters.** Low-volume routes can appear extremely efficient or inefficient based on only one or two observations.
5. **Factory mapping is complete.** All products in the supplied dataset map to one of the five factories.
6. **The dashboard makes threshold selection explicit**, allowing an analyst to test different definitions of a delayed shipment.

---

## 14. Recommendations

### Immediate
- Validate the source-system dates before operational use.
- Create automated checks for impossible or unusually long lead times.
- Monitor routes using both volume and average lead time.
- Review high-volume routes with poor performance first.

### Short term
- Establish service-level targets by ship mode.
- Compare route performance against distance and customer density.
- Add factory capacity and dispatch backlog data.
- Track weekly/monthly trends rather than relying only on overall averages.

### Long term
- Build a predictive model for expected shipping lead time.
- Estimate probability of late delivery.
- Add distance from factory to customer location.
- Incorporate carrier, warehouse, inventory availability, holidays, weather and traffic data.
- Use optimization algorithms for factory allocation and route planning.

---

## 15. Future Machine Learning Extension

A future supervised-learning model could predict shipping lead time or late-delivery probability.

### Possible features
- Factory
- Customer state
- Region
- Ship mode
- Division
- Units
- Sales
- Order month
- Customer geography
- Distance from factory
- Historical route average
- Historical route variability

### Candidate models
- Linear Regression / Ridge Regression
- Random Forest Regressor
- Gradient Boosting
- XGBoost, if permitted by the internship environment

For classification:
- Logistic Regression
- Random Forest Classifier
- Gradient Boosting Classifier

Model evaluation should use MAE/RMSE for lead-time prediction or Accuracy, Precision, Recall, F1 and ROC-AUC for delay classification.

---

## 16. Conclusion

This project converts Nassau Candy Distributor's raw order and shipment data into an interactive route-efficiency intelligence system. It demonstrates the complete data science workflow expected from an intern: data validation, cleaning, feature engineering, exploratory analysis, KPI creation, route aggregation, visualization, dashboard development and business recommendations.

The most important lesson is that **data quality must be validated before operational conclusions are trusted**. The current dataset's unusually large order-to-ship date gaps should be resolved with the source owner. Once validated, the same dashboard architecture can be extended into predictive logistics analytics and route optimization.

---

## 17. Internship Learning Outcomes

Through this project, a Data Science Intern demonstrates:
- real-world data cleaning;
- Pandas-based analysis;
- feature engineering;
- group-by and aggregation techniques;
- KPI design;
- exploratory data analysis;
- data visualization;
- geographic analytics;
- Streamlit application development;
- business-oriented interpretation of data;
- responsible handling of data-quality limitations.
