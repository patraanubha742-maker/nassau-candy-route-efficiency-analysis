### Internship Resume / Viva Description

**Project: Factory-to-Customer Shipping Route Efficiency Analysis — Nassau Candy Distributor**

Developed an end-to-end data science solution to analyze shipping efficiency across factory-to-customer routes. Cleaned and validated shipment data, engineered shipping lead-time features, mapped products to factories, created route-level KPIs, analyzed geographic and ship-mode performance, and built an interactive Streamlit dashboard using Python, Pandas and Plotly. Identified data-quality anomalies and proposed predictive logistics extensions.

**Skills demonstrated:** Python, Pandas, NumPy, Data Cleaning, EDA, Feature Engineering, KPI Analysis, Data Visualization, Geographic Analytics, Streamlit, Business Intelligence.
